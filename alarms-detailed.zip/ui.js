function updateTable(parentSelector, header, data) {
  const table = document.createElement('table');
  const tr = document.createElement('tr');
  for (const label of header) {
    const th = document.createElement('th');
    th.innerText = label;
    tr.appendChild(th);
  }
  table.appendChild(tr);

  for (const row of data) {
    const tr = document.createElement('tr');
    for (column of row) {
      const td = document.createElement('td');
      td.innerText = column;
      tr.appendChild(td);
    }
    table.appendChild(tr);
  }
  document.querySelector(parentSelector).replaceChildren(table);
}

async function updatePastList() {
  const alarms = await chrome.storage.local.get(null);

  const data = [];
  for (const time in alarms) {
    const scheduledTime = alarms[time];
    const lag = time - scheduledTime;
    data.push([scheduledTime, time, lag]);
  }
  updateTable('div#past', ["Scheduled (ms)", "Ran (ms)", "Lag (ms)"], data);
}

async function updateFutureList() {
  const alarms = await chrome.alarms.getAll();

  const data = [];
  for (const {name, scheduledTime} of alarms) {
    data.push([scheduledTime, name]);
  }
  updateTable('div#future', ["Scheduled (ms)", "Name"], data);
}

function update() {
  updatePastList();
  updateFutureList();
}

chrome.storage.onChanged.addListener(update);

// Alarm creation
document.querySelector('button').addEventListener('click', () => {
  const name = document.querySelector('input#create-name').value;
  const inputTime = document.querySelector('input#create-time').value;
  const number = Number(inputTime);
  if (Number.isNaN(number)) return;
  chrome.alarms.create(name,
  {
    when: Date.now() + number * 1000 * 60
  }).then(update);
});

// Sleep detection
const granularityMs = 1000, thresholdMs = 100;
document.querySelector('a#sleep-granularity').innerText = granularityMs;
document.querySelector('a#sleep-sensitivity').innerText = thresholdMs;
const sleep = [];
let lastRun;
setInterval(() => {
  const now = Date.now();
    if (now - lastRun > granularityMs + thresholdMs) {
    sleep.push([lastRun, now, now - lastRun]);
    updateTable('div#sleep', ["Sleep start (ms)", "Sleep end (ms)", "Sleep duration (ms)"], sleep);
  }
  lastRun = now;
}, granularityMs);

update();

