chrome.alarms.onAlarm.addListener(({scheduledTime}) =>
  chrome.storage.local.set({
    [Date.now()]: scheduledTime
}));

chrome.runtime.onInstalled.addListener(() => chrome.tabs.create({
  url: chrome.runtime.getURL('ui.html')
}));

